
public enum State { BLACK, WHITE, FINISHED }
